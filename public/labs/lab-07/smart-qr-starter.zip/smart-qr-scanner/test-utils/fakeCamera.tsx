import { Pressable, Text, View } from 'react-native';

// A fake expo-camera for tests: no real camera, and the test decides what is "scanned".
export const useCameraPermissions = jest.fn();

type Props = { onBarcodeScanned?: (scan: { type: string; data: string }) => void };

export function CameraView({ onBarcodeScanned }: Props) {
  return (
    <View>
      <Pressable testID="fake-scan-website" onPress={() => onBarcodeScanned?.({ type: 'qr', data: 'https://expo.dev' })}>
        <Text>Fake scan: website</Text>
      </Pressable>
      <Pressable testID="fake-scan-empty" onPress={() => onBarcodeScanned?.({ type: 'qr', data: '   ' })}>
        <Text>Fake scan: empty code</Text>
      </Pressable>
    </View>
  );
}
