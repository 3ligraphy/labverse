import { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import HomeScreen from './src/screens/HomeScreen';
import ScannerScreen from './src/screens/ScannerScreen';

export default function App() {
  const [screen, setScreen] = useState<'home' | 'scanner'>('home');

  return (
    <>
      <StatusBar style="light" />
      {screen === 'home' ? (
        <HomeScreen onStart={() => setScreen('scanner')} />
      ) : (
        <ScannerScreen onBack={() => setScreen('home')} />
      )}
    </>
  );
}
