# Smart QR Scanner — Lab 07 starter

A QR code scanner made with Expo SDK 58: the camera reads a QR code, the app shows what is inside it, and the phone
vibrates. In Lab 07 you finish the scanner (Part 4), test it (Parts 6–7) and build it with EAS (Part 9).

## Start

```
npm install
npx expo start
```

Scan the QR code in the terminal with **Expo Go** (Android: in Expo Go; iPhone: with the Camera app).
On the Android emulator press `a` in the terminal.

## Commands

| Command | What it does |
| --- | --- |
| `npx expo start` | starts the project for Expo Go |
| `npm test` | runs the Jest tests in `__tests__/` once |
| `npm run test:watch` | runs them again after every save |
| `maestro test .maestro/scan-sample.yaml -e APP_URL=exp://127.0.0.1:8081` | drives the app on the emulator (Part 7) |
| `eas build -p android --profile preview` | builds an APK on Expo's servers (Part 9) |

## Files

- `App.tsx` — the two screens: Home and Scanner
- `src/screens/ScannerScreen.tsx` — the camera, the permission and the scan (**Part 4, steps A, B and D**)
- `src/scan/feedback.ts` — the vibrations (**Part 4, step C**)
- `src/scan/parseScan.ts` — what is inside a QR code (website, Wi-Fi, email, phone, text)
- `src/components/` — AppButton, ScanFrame (the animated frame), ResultCard
- `__tests__/` — unit and component tests (**Part 6**)
- `test-utils/fakeCamera.tsx` — a fake camera for the tests
- `.maestro/scan-sample.yaml` — the end-to-end test (**Part 7**)
