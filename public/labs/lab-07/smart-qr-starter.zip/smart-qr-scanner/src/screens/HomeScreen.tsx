import { StyleSheet, Text, View } from 'react-native';
import AppButton from '../components/AppButton';

type Props = { onStart: () => void };

export default function HomeScreen({ onStart }: Props) {
  return (
    <View style={styles.screen}>
      <View style={styles.logo}>
        <Text style={styles.logoText}>QR</Text>
      </View>
      <Text style={styles.title}>Smart QR</Text>
      <Text style={styles.subtitle}>Scan a QR code and feel the result.</Text>
      <AppButton title="Start scanning" testID="start-scan" onPress={onStart} />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#0F172A', alignItems: 'center', justifyContent: 'center', padding: 32, gap: 16 },
  logo: { width: 96, height: 96, borderRadius: 28, borderWidth: 4, borderColor: '#38BDF8', alignItems: 'center', justifyContent: 'center' },
  logoText: { color: '#38BDF8', fontSize: 34, fontWeight: '900' },
  title: { color: '#FFFFFF', fontSize: 36, fontWeight: '800' },
  subtitle: { color: '#CBD5E1', fontSize: 17, textAlign: 'center', marginBottom: 12 },
});
