import { useRef, useState } from 'react';
import { Linking, StyleSheet, Text, View } from 'react-native';
import { CameraView, useCameraPermissions, type CameraType } from 'expo-camera';
import { parseScan, type ScanResult } from '../scan/parseScan';
import { tapFeedback } from '../scan/feedback';
import AppButton from '../components/AppButton';
import ResultCard from '../components/ResultCard';
import ScanFrame from '../components/ScanFrame';

// The fixed code the "Use sample QR" button sends, for tests (no real camera needed)
export const SAMPLE_QR = 'https://expo.dev';

type Props = { onBack: () => void };

export default function ScannerScreen({ onBack }: Props) {
  // TODO Step A: read the camera permission and the function that asks for it (useCameraPermissions)
  const [facing, setFacing] = useState<CameraType>('back');
  const [result, setResult] = useState<ScanResult | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  // TODO Step B: a lock (useRef) so one QR code is handled only once

  function handleScan(data: string) {
    // TODO Step B: stop if the lock is closed, then close it
    console.log('Scanned:', data);
    setResult(parseScan(data));
  }

  function scanAgain() {
    // TODO Step B: open the lock again
    setResult(null);
  }

  function flipCamera() {
    // TODO Step D: a small tap (tapFeedback), then switch between 'back' and 'front'
  }

  // TODO Step A: while the permission is loading (null), show "Checking camera permission…"
  // TODO Step A: when it is not granted, show "Camera permission needed" and a button:
  //              "Allow camera" (calls requestPermission) if the phone can ask again, else "Open settings"

  if (result) {
    return <ResultCard result={result} onScanAgain={scanAgain} />;
  }

  return (
    <View style={styles.screen}>
      <CameraView
        style={styles.camera}
        facing={facing}
        /* TODO Step B: read only QR codes (barcodeScannerSettings), and send each scan to handleScan (onBarcodeScanned) */
        onMountError={(error) => setCameraError(error.message)}
      />
      <ScanFrame />
      <Text style={styles.hint}>Point the camera at a QR code</Text>
      {cameraError && <Text style={styles.error}>Camera error: {cameraError}</Text>}
      <View style={styles.controls}>
        <AppButton title="Back" variant="light" onPress={onBack} />
        <AppButton title="Flip camera" variant="light" testID="flip-camera" onPress={flipCamera} />
        {__DEV__ && <AppButton title="Use sample QR" variant="light" testID="sample-scan" onPress={() => handleScan(SAMPLE_QR)} />}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#000000' },
  camera: { flex: 1 },
  center: { flex: 1, backgroundColor: '#0F172A', alignItems: 'center', justifyContent: 'center', padding: 32, gap: 16 },
  title: { color: '#FFFFFF', fontSize: 24, fontWeight: '800', textAlign: 'center' },
  text: { color: '#CBD5E1', fontSize: 16, textAlign: 'center' },
  hint: { position: 'absolute', top: 72, alignSelf: 'center', color: '#FFFFFF', fontSize: 16, fontWeight: '600' },
  error: { position: 'absolute', top: 110, left: 24, right: 24, color: '#FCA5A5', textAlign: 'center' },
  controls: { position: 'absolute', bottom: 40, left: 16, right: 16, flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 10 },
});
