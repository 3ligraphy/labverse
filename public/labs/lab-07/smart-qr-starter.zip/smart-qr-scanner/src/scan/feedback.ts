import * as Haptics from 'expo-haptics';

// TODO Step C: the phone's "success" vibration (Haptics.notificationAsync with NotificationFeedbackType.Success)
export async function successFeedback() {}

// TODO Step C: the phone's "error" vibration (Haptics.notificationAsync with NotificationFeedbackType.Error)
export async function errorFeedback() {}

// A small tap for a button press, like flipping the camera. Use it as your model for the two above.
export async function tapFeedback() {
  try {
    await Haptics.selectionAsync();
  } catch {
    // No vibration motor: nothing to do.
  }
}
