// The kinds of QR content the app understands.
export type ScanKind = 'website' | 'wifi' | 'email' | 'phone' | 'text';

// A good scan has a kind, a label and the text. A bad scan has an error message.
export type ScanResult =
  | { ok: true; kind: ScanKind; label: string; value: string }
  | { ok: false; error: string };

const MAX_LENGTH = 500;

export function parseScan(data: string | null | undefined): ScanResult {
  const value = (data ?? '').trim();
  const lower = value.toLowerCase();

  if (value === '') {
    return { ok: false, error: 'This QR code is empty.' };
  }
  if (value.length > MAX_LENGTH) {
    return { ok: false, error: 'This QR code is too long to show.' };
  }
  if (lower.startsWith('https://') || lower.startsWith('http://')) {
    return { ok: true, kind: 'website', label: 'Website', value };
  }
  if (lower.startsWith('wifi:')) {
    return { ok: true, kind: 'wifi', label: 'Wi-Fi network', value };
  }
  if (lower.startsWith('mailto:')) {
    return { ok: true, kind: 'email', label: 'Email', value };
  }
  if (lower.startsWith('tel:')) {
    return { ok: true, kind: 'phone', label: 'Phone number', value };
  }
  return { ok: true, kind: 'text', label: 'Text', value };
}
