import { useEffect, useRef } from 'react';
import { Animated, StyleSheet, View } from 'react-native';

const SIZE = 250;

export default function ScanFrame() {
  const position = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(position, { toValue: 1, duration: 1500, useNativeDriver: true }),
        Animated.timing(position, { toValue: 0, duration: 1500, useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [position]);

  const translateY = position.interpolate({ inputRange: [0, 1], outputRange: [0, SIZE - 4] });

  return (
    <View style={styles.overlay}>
      <View style={styles.frame}>
        <View style={[styles.corner, styles.topLeft]} />
        <View style={[styles.corner, styles.topRight]} />
        <View style={[styles.corner, styles.bottomLeft]} />
        <View style={[styles.corner, styles.bottomRight]} />
        <Animated.View style={[styles.line, { transform: [{ translateY }] }]} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' },
  frame: { width: SIZE, height: SIZE },
  corner: { position: 'absolute', width: 44, height: 44, borderColor: '#38BDF8' },
  topLeft: { top: 0, left: 0, borderTopWidth: 5, borderLeftWidth: 5, borderTopLeftRadius: 18 },
  topRight: { top: 0, right: 0, borderTopWidth: 5, borderRightWidth: 5, borderTopRightRadius: 18 },
  bottomLeft: { bottom: 0, left: 0, borderBottomWidth: 5, borderLeftWidth: 5, borderBottomLeftRadius: 18 },
  bottomRight: { bottom: 0, right: 0, borderBottomWidth: 5, borderRightWidth: 5, borderBottomRightRadius: 18 },
  line: { position: 'absolute', left: 12, right: 12, height: 4, borderRadius: 2, backgroundColor: '#38BDF8' },
});
