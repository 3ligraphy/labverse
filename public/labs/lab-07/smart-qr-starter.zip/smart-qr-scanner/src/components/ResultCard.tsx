import { useEffect, useRef } from 'react';
import { Animated, Linking, StyleSheet, Text, View } from 'react-native';
import type { ScanResult } from '../scan/parseScan';
import { errorFeedback, successFeedback } from '../scan/feedback';
import AppButton from './AppButton';

type Props = { result: ScanResult; onScanAgain: () => void };

export default function ResultCard({ result, onScanAgain }: Props) {
  const appear = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // The camera is closed now, so the vibration also works on iPhone.
    if (result.ok) {
      successFeedback();
    } else {
      errorFeedback();
    }
    Animated.spring(appear, { toValue: 1, friction: 6, useNativeDriver: true }).start();
  }, [result, appear]);

  const scale = appear.interpolate({ inputRange: [0, 1], outputRange: [0.8, 1] });

  return (
    <View style={styles.screen}>
      <Animated.View style={[styles.card, { opacity: appear, transform: [{ scale }] }]}>
        <View style={[styles.badge, result.ok ? styles.good : styles.bad]}>
          <Text style={styles.badgeText}>{result.ok ? '✓' : '!'}</Text>
        </View>
        <Text style={styles.label}>{result.ok ? result.label : "Can't use this code"}</Text>
        <Text style={styles.value} selectable>
          {result.ok ? result.value : result.error}
        </Text>
        {result.ok && result.kind === 'website' && (
          <Text accessibilityRole="link" style={styles.link} onPress={() => Linking.openURL(result.value)} testID="open-link">
            Open link
          </Text>
        )}
        <AppButton title="Scan again" testID="scan-again" onPress={onScanAgain} />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#0F172A', alignItems: 'center', justifyContent: 'center', padding: 24 },
  card: { width: '100%', backgroundColor: '#FFFFFF', borderRadius: 24, padding: 24, gap: 14, alignItems: 'center' },
  badge: { width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center' },
  good: { backgroundColor: '#22C55E' },
  bad: { backgroundColor: '#EF4444' },
  badgeText: { color: '#FFFFFF', fontSize: 32, fontWeight: '800' },
  label: { fontSize: 14, fontWeight: '700', color: '#64748B', textTransform: 'uppercase', letterSpacing: 1 },
  value: { fontSize: 19, color: '#0F172A', textAlign: 'center' },
  link: { fontSize: 16, color: '#0284C7', fontWeight: '700', padding: 6 },
});
