import { Pressable, StyleSheet, Text } from 'react-native';

type Props = {
  title: string;
  onPress: () => void;
  testID?: string;
  variant?: 'primary' | 'light';
};

export default function AppButton({ title, onPress, testID, variant = 'primary' }: Props) {
  return (
    <Pressable
      accessibilityRole="button"
      testID={testID}
      onPress={onPress}
      style={({ pressed }) => [styles.button, styles[variant], pressed && styles.pressed]}
    >
      <Text style={[styles.text, variant === 'light' && styles.lightText]}>{title}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: { minHeight: 52, paddingHorizontal: 22, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  primary: { backgroundColor: '#0EA5E9' },
  light: { backgroundColor: 'rgba(255,255,255,0.16)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.35)' },
  pressed: { opacity: 0.75, transform: [{ scale: 0.98 }] },
  text: { color: '#FFFFFF', fontSize: 17, fontWeight: '700' },
  lightText: { fontWeight: '600' },
});
