import { render, screen, userEvent } from '@testing-library/react-native';
import { useCameraPermissions } from 'expo-camera';
import * as Haptics from 'expo-haptics';
import ScannerScreen from '../src/screens/ScannerScreen';

jest.mock('expo-camera', () => require('../test-utils/fakeCamera'));
jest.mock('expo-haptics');

const askForCamera = jest.fn();

function givePermission(permission: { granted: boolean; canAskAgain: boolean }) {
  jest.mocked(useCameraPermissions).mockReturnValue([permission as any, askForCamera, jest.fn()]);
}

beforeEach(() => {
  jest.clearAllMocks();
});

test('asks for the camera when permission is not granted yet', async () => {
  givePermission({ granted: false, canAskAgain: true });
  await render(<ScannerScreen onBack={jest.fn()} />);

  expect(screen.getByText('Camera permission needed')).toBeOnTheScreen();

  const user = userEvent.setup();
  await user.press(screen.getByRole('button', { name: 'Allow camera' }));
  expect(askForCamera).toHaveBeenCalledTimes(1);
});

// TODO Part 6, task 4: when the phone will not ask again (canAskAgain: false), the screen shows
//   an "Open settings" button and no "Allow camera" button

test('a scanned website shows its result and the success vibration', async () => {
  givePermission({ granted: true, canAskAgain: true });
  await render(<ScannerScreen onBack={jest.fn()} />);

  const user = userEvent.setup();
  await user.press(screen.getByTestId('fake-scan-website'));

  expect(await screen.findByText('https://expo.dev')).toBeOnTheScreen();
  expect(screen.getByText('Website')).toBeOnTheScreen();
  expect(Haptics.notificationAsync).toHaveBeenCalledWith(Haptics.NotificationFeedbackType.Success);
});

// TODO Part 6, task 4: an empty code shows "This QR code is empty." and the Error vibration
//   (press the fake button with the testID 'fake-scan-empty')

test('Scan again goes back to the camera', async () => {
  givePermission({ granted: true, canAskAgain: true });
  await render(<ScannerScreen onBack={jest.fn()} />);

  const user = userEvent.setup();
  await user.press(screen.getByTestId('fake-scan-website'));
  await user.press(await screen.findByRole('button', { name: 'Scan again' }));

  expect(screen.getByTestId('fake-scan-website')).toBeOnTheScreen();
});
