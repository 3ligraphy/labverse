import { parseScan } from '../src/scan/parseScan';

describe('parseScan', () => {
  test('a website link is a website', () => {
    const result = parseScan('https://expo.dev');
    expect(result).toEqual({ ok: true, kind: 'website', label: 'Website', value: 'https://expo.dev' });
  });

  // TODO Part 6, task 2: a Wi-Fi code is a Wi-Fi network
  //   parseScan('WIFI:S:Lab-5G;T:WPA;P:secret123;;') gives ok: true and kind: 'wifi'

  test('email and phone codes are recognized', () => {
    expect(parseScan('mailto:ta@example.com')).toMatchObject({ ok: true, kind: 'email' });
    expect(parseScan('tel:+15555550100')).toMatchObject({ ok: true, kind: 'phone' });
  });

  test('anything else is plain text', () => {
    expect(parseScan('Room 3.12')).toMatchObject({ ok: true, kind: 'text', value: 'Room 3.12' });
  });

  test('spaces around the code are removed', () => {
    expect(parseScan('   https://expo.dev   ')).toMatchObject({ value: 'https://expo.dev' });
  });

  // TODO Part 6, task 2: an empty code is an error
  //   parseScan(''), parseScan('    ') and parseScan(null) all give { ok: false, error: 'This QR code is empty.' }

  test('a very long code is an error', () => {
    const result = parseScan('x'.repeat(501));
    expect(result.ok).toBe(false);
  });
});
